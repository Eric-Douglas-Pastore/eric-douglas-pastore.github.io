import copy
import random

#Takes argument of 2d array of boolean integers
def updateGoLstate(currState):
    newState = copy.deepcopy(currState)
    
    #Calculate neighboring cells for each cell
    
    #Look at each row in state
    for i in range(len(currState)):
        #Look at each column in the row
        for j in range(len(currState[i])):
            #calculate neighbors
            neighbors = 0
            
            #Add all 9 cells in region centered on current cell
            for k in range(3):
                for L in range(3):
                    try:
                        if (i + k - 1) >= 0 and (j + L - 1) >= 0:
                            neighbors += (currState[i + k - 1][j + L - 1] == 1)
                    except:
                        IndexError
            
            neighbors += -1*currState[i][j] #Subtract the self
            
            #print(i, j, neighbors)
                        
            #Rule 1:
            #    If dead, born if exactly 2 neighbors
            if currState[i][j] == 0 and neighbors == 2:
                newState[i][j] = 1
            #Rule 2:
            #    If alive, and 2-3 neighbors, stay alive -- needs no updates
            #Rule 3:
            #    If alive, and <2 or >3 neighbors, die
            if currState[i][j] == 1 and not (neighbors == 2 or neighbors == 3):
                newState[i][j] = 0
                
    del currState
    return newState

#Code Courtesy of Google's Generative AI
def drawPred(currState,x,y,dx,dy,energy):
    newState = copy.deepcopy(currState)
    try:
        #Do we have any energy to expend?
        if energy > 0:
            for i in range(3):
                for j in range(3):
                        newState[x+i-1][y+j-1] = 0
            # Move the cell
            x += dx
            y += dy
        
            # Check for wall collisions
            if x+2 >= len(currState) or x-1 <= 0:
                dx *= -1
            if y+2 >= len(currState) or y-1 <= 0:
                dy *= -1
    
            # Update the cell position
            for i in range(3):
                for j in range(3):
                    if i == 1 and j == 1:
                        newState[x+i-1][y+j-1] = 3
                    else:
                        newState[x+i-1][y+j-1] = 2
        else:
            for i in range(3):
                for j in range(3):
                    newState[x+i-1][y+j-1] = 1
             
    except:
        IndexError
    newX = x
    newY = y
    new_dx = dx
    new_dy = dy
    del currState
    return newState, newX, newY, new_dx, new_dy

def predReproduce(currState,energy,x,y,dx,dy):
    newState = copy.deepcopy(currState)
    method = 0
    if energy > 50:
        if random.random() < 0.35:
            method = 1
        elif 0.35 <= random.random() < 0.55:
            method = 2
        elif 0.55 <= random.random() < 0.7:
            method = 3
        else:
            method = 4
    return method
def eatCells(currState,x,y,dx,dy,energy):
    newState = copy.deepcopy(currState)
    try:
        for i in range(5):
            for j in range(5):
                if currState[x+i-2][y+j-2] == 1 and energy > 0:
                    newState[x+i-2][y+j-2] = 0
                    energy += 1
    except:
        IndexError
    del currState
    return newState, energy
