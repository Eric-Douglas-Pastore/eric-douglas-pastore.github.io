#Conway's Game Of Life
#Author: RR & CIS343-F24
#Last Updated: 9/24/2024

#Goals: Simulate Conway's GoL
#       Simulate a random initial state of the system
#       Visualize the state of the system in each step
#       Analyze how many cells are alive per step

import random
import matplotlib.pyplot as plt
import numpy as np
import Functions as gol
from collections import OrderedDict

#Empty array for the overall system state
state = []

#Add a list to track number of living cells per step
records = []

#Initializes a random selection of initially living cells
start = 50
size = 10

births = []
for i in range(start):
    check = random.randint(0, size*size)
    while check in births:
        check = random.randint(0, size*size)
    births.append(check)

#Initializes system state based on RNG above
for i in range(size):
    row = []
    for j in range(size):
        row.append(0)
        if i*size + j in births:
            row[-1]=1
    state.append(row)

numPreds = 0
x = []
y = []
dx = []
dy = []
energy = []
#These loops generate the Predator(s)
for i in range(3):
    for j in range(3):
        if i == 1 and j == 1:
            state[i+2][j+2] = 3
        else:
            state[i+2][j+2] = 2
        #state[i+3][j+3] = 2
        #state[i+9][j+9] = 2
x.append(3)
y.append(3)
dx.append(0)
dy.append(1)
energy.append(50)
"""
x.append(4)
y.append(4)
dx.append(1)
dy.append(0)
energy.append(25)
x.append(10)
y.append(10)
dx.append(1)
dy.append(0)
energy.append(10)
"""
numPreds = len(x)
numDedPreds = 0
predators = {}
for i in range(numPreds):
    predators[i] = (x[i],y[i],dx[i],dy[i],energy[i])
living = [x for line in state for x in line if x == 1]
records.append(len(living))

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(5, 7), height_ratios = [3, 1])

#Visualize the system state
#Blue = Nothing
#Yellow = Predator
#Teal = Prey
ax1.imshow(state)
plt.ion()
plt.show()
ax2.plot(range(len(records)), records)

#Run the simulation for 250 steps, or until all dead
for i in range(250):
    #Update the state based on Conway's rules
    state = gol.updateGoLstate(state)
    
    #Calculating number of living cells
    living = [x for line in state for x in line if x == 1]
    records.append(len(living))
    try:
        for j in range(numPreds-numDedPreds):
            predators[j] = (x[j],y[j],dx[j],dy[j],energy[j])
    except:
        IndexError
    if (len(living)) == 0:
        break
    try:
        for j in range(numPreds):
            state, energy[j] = gol.eatCells(state,x[j],y[j],dx[j],dy[j],energy[j])        
            if energy[j] > 0:
                energy[j] -= min(energy[j],5)
                print(energy[j])
            else:
                predators[j] = predators.pop(j)
                del x[j]
                del y[j]
                del dx[j]
                del dy[j]
                del energy[j]
                del predators[j]
                numPreds -= 1
                print(len(predators))
    except:
        IndexError
    ax1.cla()
    ax1.imshow(state)
    plt.show(block=False)#prevents halt from plot
    plt.pause(0.01) #pause for human vision
    ax2.cla()
    ax2.plot(range(len(records)), records)
    try:
        for j in range(numPreds):
            state, x[j], y[j], dx[j], dy[j] = gol.drawPred(state,x[j],y[j],dx[j],dy[j],energy[j])
            if gol.predReproduce(state,energy[j],x[j],y[j],dx[j],dy[j]) == 1:
                if dx[j] == 1 and dy[j] == 0:
                    x.append(x[j])
                    y.append(y[j])
                    dx.append(0)
                    dy.append(-1)
                    energy[j] /= 2
                    energy.append(energy[j])
                    if numPreds >= 0:
                        numPreds += 1
                elif dx[j] == 0 and dy[j] == 1:
                    x.append(x[j])
                    y.append(y[j])
                    dx.append(-1)
                    dy.append(0)
                    energy[j] /= 2
                    energy.append(energy[j])
                    if numPreds >= 0:
                        numPreds += 1
                elif dx[j] == -1 and dy[j] == 0:
                    x.append(x[j])
                    y.append(y[j])
                    dx.append(0)
                    dy.append(1)
                    energy[j] /= 2
                    energy.append(energy[j])
                    if numPreds >= 0:
                        numPreds += 1
                elif dx[j] == 0 and dy[j] == -1:
                    x.append(x[j])
                    y.append(y[j])
                    dx.append(1)
                    dy.append(0)
                    energy[j] /= 2
                    energy.append(energy[j])
                    if numPreds >= 0:
                        numPreds += 1
            if gol.predReproduce(state,energy[j],x[j],y[j],dx[j],dy[j]) == 2:
                x.append(x[j])
                y.append(y[j])
                if dy[j] == 0:
                    dx.append(-1)
                    dy.append(0)
                    dx.append(1)
                    dy.append(0)
                    energy.append(energy[j]/2)
                elif dx[j] == 0:
                    dx.append(1)
                    dy.append(0)
                    dx.append(-1)
                    dy.append(0)
                    energy.append(energy[j]/2)
                numPreds += 2
                del x[j]
                del y[j]
                del dx[j]
                del dy[j]
                del energy[j]
                del predators[j]
                numPreds -= 1
            if gol.predReproduce(state,energy[j],x[j],y[j],dx[j],dy[j]) == 3:
                energy[j] /= 2
                x.append(x[j])
                y.append(y[j])
                if dx[j] == 1 and dy[j] == 0:
                    dx.append(-1)
                    dy.append(0)
                elif dx[j] == 0 and dy[j] == 1:
                    dx.append(0)
                    dy.append(-1)
                elif dx[j] == -1 and dy[j] == 0:
                    dx.append(1)
                    dy.append(0)
                elif dx[j] == 0 and dy[j] == -1:
                    dx.append(0)
                    dy.append(1)
                energy.append(energy[j])
                if numPreds >= 0:
                    numPreds += 1
            if gol.predReproduce(state,energy[j],x[j],y[j],dx[j],dy[j]) == 4:
                energy[j] /= 4
                for k in range(3):
                    x.append(x[j])
                    y.append(y[j])
                    if k == 0:
                        if dx[j] == 1 and dy[j] == 0:
                            dx.append(-1)
                            dy.append(0)
                        elif dx[j] == 0 and dy[j] == 1:
                            dx.append(0)
                            dy.append(-1)
                        elif dx[j] == -1 and dy[j] == 0:
                            dx.append(1)
                            dy.append(0)
                        elif dx[j] == 0 and dy[j] == -1:
                            dx.append(0)
                            dy.append(1)
                    energy.append(energy[j])
                    if k == 1:
                        if dx[j] == 1 and dy[j] == 0:
                            dx.append(0)
                            dy.append(1)
                        elif dx[j] == 0 and dy[j] == 1:
                            dx.append(-1)
                            dy.append(0)
                        elif dx[j] == -1 and dy[j] == 0:
                            dx.append(0)
                            dy.append(-1)
                        elif dx[j] == 0 and dy[j] == -1:
                            dx.append(1)
                            dy.append(0)
                        energy.append(energy[j])
                    if k == 2:
                        if dx[j] == 1 and dy[j] == 0:
                            dx.append(0)
                            dy.append(-1)
                        elif dx[j] == 0 and dy[j] == 1:
                            dx.append(1)
                            dy.append(0)
                        elif dx[j] == -1 and dy[j] == 0:
                            dx.append(0)
                            dy.append(1)
                        elif dx[j] == 0 and dy[j] == -1:
                            dx.append(-1)
                            dy.append(0)
                        energy.append(energy[j])
                    numPreds += 1
    except:
        IndexError
    ax1.imshow(state)
plt.ioff()
plt.show()
#NOTE: the python code doesn't end until plot closed



